<?php
    session_start();
    error_reporting(0);
    include('connection.php');

    if (isset($_POST['sub'])) {
        $email = $_POST['email'];
        $password = $_POST['password']; // Note: Using MD5 for hashing is not secure. Consider using stronger hashing algorithms like bcrypt.
    
        $query = mysqli_query($con, "SELECT * FROM user WHERE email='$email' AND password='$password'");
        $result = mysqli_fetch_assoc($query);
    
        if ($result) {
            // User exists, create session variables and redirect to games.php
            $_SESSION['uid'] = $result['id']; // Assuming you have an 'id' field in your 'user' table
            $_SESSION['un'] = $result['name'];
            $_SESSION['email'] = $result['email'];
            $_SESSION['phone'] = $result['phone']; // Assuming you have a 'phone' field in your 'user' table
            header("Location: index.php");
            exit();
        } else {
            echo "<script>alert('Invalid email or password. Please try again.');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Zipper - Responsive HTML Template</title>
<!--

Template 2084 Zipper

http://www.tooplate.com/view/2084-zipper

-->
    <!-- load stylesheets -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400">  <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">                <!-- Font Awesome -->
    <link rel="stylesheet" href="css/bootstrap.min.css">                                      <!-- Bootstrap style -->
    <link rel="stylesheet" href="css/tooplate-style.css">                                   <!-- Templatemo style -->
    <link rel="stylesheet" href="css/style.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
          <![endif]-->
</head>

    <body background="img/shoes.webp">

        <div class="container-fluid">
            <!-- Navigation -->        
            <div class="tm-nav navfixed">
                <nav class="navbar navbg">

                    <button class="navbar-toggler hidden-md-up" type="button" data-toggle="collapse" data-target="#tmNavbar"></button> <!-- &#9776; ☰ -->
                    <div class="collapse navbar-toggleable-sm text-xs-center tm-navbar" id="tmNavbar">
                        <ul class="nav navbar-nav">
                            <li class="nav-item active selected">
                                <a class="nav-link current" href="./index.php">Home <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./girl.php">For Girl</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./men.php">For Men</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./contact.php">Contact</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            
            <section class="tm-section tm-section-home tm-flex-center" id="home" style="min-height: 800px;">                
                
                <div class="tm-hero">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="text-uppercase tm-hero-title">Online Shoes Store</h1><br><br>                            
                        </div>
                        
                        <center>
                            <?php 
                             if(strlen($_SESSION['uid'])==0){
                                ?>
                              <div class="tm-bg-black-translucent" style="padding:5px;color:white;">
                            <h3>Login</h3>
                            <form method="post" class="tm-contact-form">
                                <input type="email" name="email" placeholder="Email" class="form-control2" /><br/><br/>
                                <input type="password" name="password" placeholder="Password" class="form-control2" /><br/><br/>
                                <span>Create New Account.</span><a href="./register.php">Register</a><br/>
                                <div class="col-12">
                                    <input type="submit" name="sub"  value="LOGIN" class="submit_button btn btn-primary mt-2" />
                                </div>
                            </form>
                        </div>   
                            <?php
                            }else{
                                echo "<h3 style='padding:5px;color:white;'>Welcome ".$_SESSION['un']."</h3><br/>";
                                echo "<h3 style='padding:5px;color:white;'><a href='logout.php'>Logout</a></h3>";
                            }
                          ?>
                    </center>
                    </div>                    
                </div>             
            </section>

             <!-- load JS files -->
        <script src="js/jquery-1.11.3.min.js"></script>         <!-- jQuery (https://jquery.com/download/) -->
        <script src="https://www.atlasestateagents.co.uk/javascript/tether.min.js"></script> <!-- Tether for Bootstrap (http://stackoverflow.com/questions/34567939/how-to-fix-the-error-error-bootstrap-tooltips-require-tether-http-github-h) -->
        <script src="js/bootstrap.min.js"></script>             <!-- Bootstrap js (v4-alpha.getbootstrap.com/) -->
        <script src="js/jquery.singlePageNav.min.js"></script>  <!-- Single page nav (https://github.com/ChrisWojcik/single-page-nav) -->

</body>
</html>